from scherry.utils.expose import run

run("hello_world")