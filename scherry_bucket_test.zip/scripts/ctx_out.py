

seq = globals().get("ScherrySeq")

print("current sequence is " + seq)

assert globals().get("a") == 1
assert globals().get("b") == 2