

seq = globals().get("ScherrySeq")

print("current sequence is " + str(seq))

assert globals().get("a") == 1
assert globals().get("b") == 2