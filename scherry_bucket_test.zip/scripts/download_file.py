
from scherry.utils.file import extra_file


extra_file("awesome.tex")