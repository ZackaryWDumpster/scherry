from scherry.core.mgr import ScherryMgr

mgr = ScherryMgr()
print(mgr.bucket_list_installed())