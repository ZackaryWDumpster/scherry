
seq = globals().get("ctx").currentSeq

print("current sequence is " + str(seq))

dataOut = {
    "a" : 1,
    "b" : 2
}