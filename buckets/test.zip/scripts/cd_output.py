
import os


if not os.path.exists("output"):
    os.makedirs("output")
os.chdir("output")